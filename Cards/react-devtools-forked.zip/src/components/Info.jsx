import React from "react";

function Info(props) {
  return <p className="info">{props.detail}</p>;
}

export default Info;
